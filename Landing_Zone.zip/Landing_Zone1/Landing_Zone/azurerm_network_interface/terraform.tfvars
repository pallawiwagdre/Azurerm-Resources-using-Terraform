pallawi-nic = {
  pallawi-nic-1 = {
    name                          = "pallawiic1"
    location                      = "CentralIndia"
    resource_group_name           = "rg1"
    subnet_id                     = "/subscriptions/54db10a3-bd86-4105-8cb9-8454e707392d/resourceGroups/rg1/providers/Microsoft.Network/virtualNetworks/vnet-demo-eastus11/subnets/sub-net1"
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = "/subscriptions/54db10a3-bd86-4105-8cb9-8454e707392d/resourceGroups/rg1/providers/Microsoft.Network/publicIPAddresses/pallawiip"
    network_security_group_id     = "/subscriptions/54db10a3-bd86-4105-8cb9-8454e707392d/resourceGroups/rg1/providers/Microsoft.Network/networkSecurityGroups/pallawi-nsg"
  }
}