virtual_machine = {
  vm = {
    name                = "pallawi-vm"
    location            = "centralindia"
    resource_group_name = "rg1"

    network_interface_ids = [
      "/subscriptions/54db10a3-bd86-4105-8cb9-8454e707392d/resourceGroups/rg1/providers/Microsoft.Network/networkInterfaces/pallawiic1"
    ]

    vm_size = "Standard_D2s_v3"

    storage_image_reference = {
      publisher = "Canonical"
      offer     = "0001-com-ubuntu-server-jammy"
      sku       = "22_04-lts"
      version   = "latest"
    }

    storage_os_disk = {
      name              = "myosdisk1"
      caching           = "ReadWrite"
      create_option     = "FromImage"
      managed_disk_type = "Standard_LRS"
    }

    os_profile = {
      computer_name  = "linux"
      admin_username = "pallawiuser"
      admin_password = "Password1234!"
    }
  }
}