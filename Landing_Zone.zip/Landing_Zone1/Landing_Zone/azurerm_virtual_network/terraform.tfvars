virtual_net = {
  vnet11 = {
    name                = "vnet-demo-eastus11"
    address_space       = ["10.0.0.0/16"]
    location            = "centralindia"
    resource_group_name = "rg1"
  }

  vnet22 = {
    name                = "vnet-demo-eastus22"
    address_space       = ["10.1.0.0/16"]
    location            = "westus"
    resource_group_name = "rg2"
  }
}