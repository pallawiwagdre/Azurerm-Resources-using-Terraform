# resource "azurerm_resource_group" "rg" {
#   name     = "rg-demo-eastus2"
#   location = "East US 2"
# }

resource "azurerm_virtual_network" "vnet" {
  for_each            = var.virtual_net
  name                = each.value.name
  address_space       = each.value.address_space
  location            = each.value.location
  resource_group_name = each.value.resource_group_name
}