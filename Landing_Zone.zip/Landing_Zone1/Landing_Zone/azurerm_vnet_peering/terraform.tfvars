peering1 = {
  peer = {
    name                      = "peer1"
    resource_group_name       = "rg1"
    virtual_network_name      = "vnet-demo-eastus11"
    remote_virtual_network_id = "/subscriptions/54db10a3-bd86-4105-8cb9-8454e707392d/resourceGroups/rg2/providers/Microsoft.Network/virtualNetworks/vnet-demo-eastus22"
  }
}

peering2 = {
  peer2 = {
    name                      = "peer2"
    resource_group_name       = "rg2"
    virtual_network_name      = "vnet-demo-eastus22"
    remote_virtual_network_id = "/subscriptions/54db10a3-bd86-4105-8cb9-8454e707392d/resourceGroups/rg1/providers/Microsoft.Network/virtualNetworks/vnet-demo-eastus11"
  }
}