bastion_subnet = {
  bastion_subnet1 = {
    name                 = "AzureBastionSubnet"
    resource_group_name  = "rg1"
    virtual_network_name = "vnet-demo-eastus11"
    address_prefixes     = ["10.0.10.0/26"]
  }
}

public_ip = {
  public_ip = {
    name                = "pallawiip1"
    location            = "centralindia"
    resource_group_name = "rg2"
  }
}

bastion = {
  azure_bastion = {
    name                = "bastion-demo"
    location            = "centralindia"
    resource_group_name = "rg1"
  }
}