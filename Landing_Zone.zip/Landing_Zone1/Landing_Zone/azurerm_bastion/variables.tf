variable bastion_subnet {}
variable public_ip {}
variable bastion {}