resource "azurerm_resource_group" "dev" {
  for_each = var.x
  name     = each.key
  location = each.value
}