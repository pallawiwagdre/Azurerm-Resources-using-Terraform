x = { 
    "rg1" = "southindia",
    "rg2" = "centralindia",
    "rg3" = "southindia",
    "rg4" = "eastus" 
    }