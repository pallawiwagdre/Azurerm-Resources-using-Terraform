subnetwork = {
  subnet1 = {
    name                 = "sub-net1"
    resource_group_name  = "rg1"
    virtual_network_name = "vnet-demo-eastus11"
    address_prefixes     = ["10.0.3.0/24"]
  }

  subnet2 = {
    name                 = "sub-vnet2"
    resource_group_name  = "rg2"
    virtual_network_name = "vnet-demo-eastus22"
    address_prefixes     = ["10.1.1.0/24"]
  }
}