storage = {
  sa1 = {
    name                     = "pallawistorage00123"
    resource_group_name      = "rg1"
    location                 = "eastus"
    account_tier             = "Standard"
    account_replication_type = "GRS"
  }

  sa2 = {
    name                     = "pallawistorage00234"
    resource_group_name      = "rg2"
    location                 = "centralindia"
    account_tier             = "Standard"
    account_replication_type = "GRS"
  }
}