ip = {
  public_ip = {

    name                = "pallawiip"
    location            = "centralindia"
    resource_group_name = "rg1"
    allocation_method   = "Static"
  }
}